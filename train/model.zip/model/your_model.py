## 这是一个占位文件

## 定义自己的语义分割模型
## 模型输出为一个通道

# For example, a simple model could be defined as follows:
import torch
import torch.nn as nn

class your_model(nn.Module):
    def __init__(self, num_classes):
        super(your_model, self).__init__()
        # 定义模型的层
        self.conv1 = torch.nn.Conv2d(3, 64, kernel_size=3, padding=1)
        self.conv2 = torch.nn.Conv2d(64, num_classes, kernel_size=3, padding=1)
        # 添加更多层...

    def forward(self, x):
        dict_return = {}
        # 定义前向传播
        x = self.conv1(x)
        x = torch.relu(x)
        x = self.conv2(x)
        dict_return['out'] = x
        return dict_return
