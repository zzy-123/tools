import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np

# img_shape = (args.channels, args.img_size, args.img_size)
# img_shape = (1, 512, 512)
latent_dim = 10


class AAE(nn.Module):
    def __init__(self, in_features, h_features=512, z_features=12):
        super(AAE, self).__init__()
        self.in_features = in_features
        # 编码器
        self.encoder = nn.Sequential(
            nn.Linear(in_features, h_features),
            nn.LeakyReLU(0.2, inplace=True),
            # nn.ReLU(),
            nn.Linear(h_features, h_features),
            nn.BatchNorm1d(h_features),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(h_features, z_features)
        )
        # 解码器
        self.decoder = nn.Sequential(
            nn.Linear(z_features, h_features),
            # nn.ReLU(),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(h_features, h_features),
            nn.BatchNorm1d(h_features),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(h_features, in_features),
            nn.Sigmoid()
        )
        # 判别器
        self.discriminator = nn.Sequential(
            nn.Linear(z_features, h_features),
            # nn.ReLU(),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(h_features, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.reshape(-1, self.in_features)
        z = self.encoder(x)
        recon_x = self.decoder(z)
        validity = self.discriminator(z)
        return recon_x, validity

class AAE_Conv(nn.Module):
    def __init__(self):
        super(AAE_Conv, self).__init__()
        self.encoder = Encoder_Conv()
        self.decoder = Decoder_Conv()
        self.discriminator = Discriminator_Conv()

    def forward(self, img):
        z = self.encoder(img)
        recon_img = self.decoder(z)
        validity = self.discriminator(z)
        return recon_img, validity

    def sample(self, z):
        return self.decoder(z)

    def encode(self, img):
        return self.encoder(img)

    def discriminate(self, z):
        return self.discriminator(z)

#######################################################
# Define Networks
#######################################################

class Encoder(nn.Module):
    def __init__(self, img_shape):
        super(Encoder, self).__init__()
        self.img_shape = img_shape
        self.model = nn.Sequential(
            nn.Linear(int(self.img_shape[0] * self.img_shape[1] * self.img_shape[2]), 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, latent_dim)
        )

        self.mu = nn.Linear(512, latent_dim)
        self.logvar = nn.Linear(512, latent_dim)

    def forward(self, img):

        img = img.reshape(-1, self.img_shape[0], self.img_shape[1], self.img_shape[2])
        img_flat = img.view(img.shape[0], -1)
        x = self.model(img_flat)
        # mu = self.mu(x)
        # logvar = self.logvar(x)
        # z = reparameterization(mu, logvar)
        return x


class Decoder(nn.Module):
    def __init__(self, img_shape):
        super(Decoder, self).__init__()
        self.img_shape = img_shape

        self.model = nn.Sequential(
            nn.Linear(latent_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, int(np.prod(self.img_shape))),
            nn.Tanh(),
        )

    def forward(self, z):
        img_flat = self.model(z)
        img = img_flat.view(img_flat.shape[0], *self.img_shape)
        return img


class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(latent_dim, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 1),
            nn.Sigmoid(),
        )

    def forward(self, z):
        validity = self.model(z)
        return validity


def compute_gray_co_occurrence_matrix(image, distances=[2, 8, 16], angles=[0, np.pi / 4, np.pi / 2, np.pi * 3 / 4],
                                      levels=256):
    # angles = [angles[0]*np.pi/180, angles[1]*np.pi/180, angles[2]*np.pi/180, angles[3]*np.pi/180]
    batch_size, channels, height, width = image.shape
    # Convert image to grayscale if it's not already
    if channels == 3:  # RGB image
        image = torch.mean(image, dim=1, keepdim=True)  # Convert to grayscale
    # Normalize image to range [0, levels - 1]
    image = (image * (levels - 1) / levels).int()
    # Initialize co-occurrence matrix
    co_occurrence_matrix = torch.zeros(batch_size, levels, levels, len(distances), len(angles))

    for d, distance in enumerate(distances):
        for a, angle in enumerate(angles):
            # Generate offset for this angle
            offset = torch.tensor([distance * np.cos(angle), distance * np.sin(angle)], dtype=torch.int)

            # Compute shifted images
            shifted_image = F.pad(image, (abs(offset[1]), abs(offset[1]), abs(offset[0]), abs(offset[0])))
            shifted_image = shifted_image[:, :, max(0, int(offset[1])):shifted_image.shape[2] - max(0, -int(offset[1])),
                            max(0, int(offset[0])):shifted_image.shape[3] - max(0, -int(offset[0]))]

            shifted_image_offset = F.pad(image, (abs(offset[1]), abs(offset[1]), abs(offset[0]), abs(offset[0])))
            shifted_image_offset = shifted_image_offset[:, :,
                                   max(0, -int(offset[1])):shifted_image_offset.shape[2] - max(0, int(offset[1])),
                                   max(0, -int(offset[0])):shifted_image_offset.shape[3] - max(0, int(offset[0]))]

            # Compute co-occurrence matrix
            for i in range(batch_size):
                co_occurrence_matrix[i, :, :, d, a] = torch.sum(
                    (shifted_image[i] == shifted_image_offset[i]).to(torch.float), dim=(1, 2))

    return co_occurrence_matrix


def compute_texture_features(co_occurrence_matrix):
    # Compute texture features (contrast, dissimilarity, homogeneity, energy)
    contrast = torch.mean(torch.square(torch.arange(co_occurrence_matrix.shape[1]).view(1, -1, 1, 1, 1).expand(
        co_occurrence_matrix.shape) - torch.arange(co_occurrence_matrix.shape[2]).view(1, 1, -1, 1, 1).expand(
        co_occurrence_matrix.shape)) * co_occurrence_matrix, dim=(1, 2))
    dissimilarity = torch.mean(torch.abs(torch.arange(co_occurrence_matrix.shape[1]).view(1, -1, 1, 1, 1).expand(
        co_occurrence_matrix.shape) - torch.arange(co_occurrence_matrix.shape[2]).view(1, 1, -1, 1, 1).expand(
        co_occurrence_matrix.shape)) * co_occurrence_matrix, dim=(1, 2))
    homogeneity = torch.mean(co_occurrence_matrix / (1 + torch.abs(
        torch.arange(co_occurrence_matrix.shape[1]).view(1, -1, 1, 1, 1).expand(
            co_occurrence_matrix.shape) - torch.arange(co_occurrence_matrix.shape[2]).view(1, 1, -1, 1, 1).expand(
            co_occurrence_matrix.shape))), dim=(1, 2))
    energy = torch.mean(torch.square(co_occurrence_matrix), dim=(1, 2))

    return contrast, dissimilarity, homogeneity, energy


def mask(image, mask):
    mask = (mask > 0.5)
    mask_image = torch.masked_select(image, mask)
    return mask_image


# 定义 Encoder 模型
class Encoder_Conv(nn.Module):
    # def __init__(self):
    #     super(Encoder_Conv, self).__init__()
    #     self.conv1 = nn.Conv2d(1, 32, 3, stride=2, padding=1)
    #     self.conv2 = nn.Conv2d(32, 64, 3, stride=2, padding=1)
    #     self.fc = nn.Linear(64*16*16, 32)
    #
    # def forward(self, x):
    #     x = torch.relu(self.conv1(x))
    #     x = torch.relu(self.conv2(x))
    #     x = x.view(-1, 64*16*16)
    #     x = self.fc(x)
    #     return x
    def __init__(self):
        super(Encoder_Conv, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=7)
        )
        self.gap = nn.AdaptiveAvgPool2d((1, 1))  # 全局平均池化层
        self.z_layer = nn.Linear(64, 10)

    def forward(self, x):
        x = self.conv_layers(x)
        x = self.gap(x)  # 应用全局平均池化
        x = x.view(x.size(0), -1)  # 将池化后的特征图扁平化
        z = self.z_layer(x)
        return z


# 定义 Decoder 模型
class Decoder_Conv(nn.Module):
    # def __init__(self):
    #     super(Decoder_Conv, self).__init__()
    #     self.fc = nn.Linear(32, 64*16*16)
    #     self.conv1 = nn.ConvTranspose2d(64, 32, 3, stride=2, padding=1, output_padding=1)
    #     self.conv2 = nn.ConvTranspose2d(32, 1, 3, stride=2, padding=1, output_padding=1)
    #
    # def forward(self, x):
    #     x = self.fc(x)
    #     x = x.view(-1, 64, 16, 16)
    #     x = torch.relu(self.conv1(x))
    #     x = torch.sigmoid(self.conv2(x))
    #     return x
    def __init__(self):
        super(Decoder_Conv, self).__init__()
        self.output_size = (256, 256)
        self.linear_layers = nn.Sequential(
            nn.Linear(10, 64),
            nn.ReLU()
        )
        self.deconv_layers = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=32, kernel_size=7),
            nn.ReLU(),
            nn.ConvTranspose2d(in_channels=32, out_channels=16, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.ReLU(),
            nn.ConvTranspose2d(in_channels=16, out_channels=1, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Sigmoid()
        )

    def forward(self, z):
        z = self.linear_layers(z)
        z = z.view(z.size(0), 64, 1, 1)
        x = self.deconv_layers(z)
        # 使用 interpolate 函数进行自适应上采样
        x = F.interpolate(x, size=self.output_size, mode='bilinear', align_corners=False)
        return x


# 定义 Discriminator 模型
class Discriminator_Conv(nn.Module):
    # def __init__(self):
    #     super(Discriminator_Conv, self).__init__()
    #     self.fc = nn.Linear(32, 128)
    #     self.out = nn.Linear(128, 1)
    #     self.sigmoid = nn.Sigmoid()
    #
    # def forward(self, x):
    #     x = torch.relu(self.fc(x))
    #     x = self.sigmoid(self.out(x))
    #     return x
    def __init__(self):
        super(Discriminator_Conv, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(10, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, z):
        validity = self.layers(z)
        return validity


if __name__ == "__main__":
    # Example usage
    image = torch.rand(8, 3, 256, 256)  # Example random RGB image
    co_occurrence_matrix = compute_gray_co_occurrence_matrix(image)
    print(co_occurrence_matrix.shape)
    contrast, dissimilarity, homogeneity, energy = compute_texture_features(co_occurrence_matrix)
    print("Contrast:", contrast.shape)
    print("Dissimilarity:", dissimilarity)
    print("Homogeneity:", homogeneity)
    print("Energy:", energy.mean())

    # lr = 0.0002
    # b1 = 0.5
    # b2 = 0.999
    # # define model
    # # 1) generator
    # encoder = Encoder()
    # decoder = Decoder()
    # # 2) discriminator
    # discriminator = Discriminator()
    #
    # # loss
    # adversarial_loss = nn.BCELoss()
    # reconstruction_loss = nn.MSELoss()
    #
    # # optimizer
    # optimizer_G = torch.optim.Adam(itertools.chain(encoder.parameters(), decoder.parameters()), lr=lr, betas=(b1, b2))
    # optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=lr, betas=(b1, b2))
    # encoder.cuda()
    # decoder.cuda()
    # discriminator.cuda()
    # adversarial_loss.cuda()
    # reconstruction_loss.cuda()
    # Tensor = torch.cuda.FloatTensor
    # n_epochs = 200
    # for epoch in range(n_epochs):
    #     x = torch.rand(8, 1, 512, 512).float()
    #
    #     valid = Variable(Tensor(x.shape[0], 1).fill_(1.0), requires_grad=False)
    #     fake = Variable(Tensor(x.shape[0], 1).fill_(0.0), requires_grad=False)
    #     x = x.cuda()
    #     # 1) reconstruction + generator loss
    #     optimizer_G.zero_grad()
    #     fake_z = encoder(x)
    #     decoded_x = decoder(fake_z)
    #     validity_fake_z = discriminator(fake_z)
    #     G_loss = 0.001 * adversarial_loss(validity_fake_z, valid) + 0.999 * reconstruction_loss(decoded_x, x)
    #     G_loss.backward()
    #     optimizer_G.step()
    #
    #     # 2) discriminator loss
    #     optimizer_D.zero_grad()
    #     real_z = Variable(Tensor(np.random.normal(0, 1, (x.shape[0], latent_dim))))
    #     real_loss = adversarial_loss(discriminator(real_z), valid)
    #     fake_loss = adversarial_loss(discriminator(fake_z.detach()), fake)
    #     D_loss = 0.5 * (real_loss + fake_loss)
    #     D_loss.backward()
    #     optimizer_D.step()
    #     print(
    #         "[Epoch %d/%d] [G loss: %f] [D loss: %f]"
    #         % (epoch, n_epochs, G_loss.item(), D_loss.item())
    #     )
